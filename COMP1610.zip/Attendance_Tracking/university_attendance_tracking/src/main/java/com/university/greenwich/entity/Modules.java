package com.university.greenwich.entity;


import java.util.List;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;


@Entity
public class Modules {
	
	@Id
	private String shortCode;
	
	private String longName;
	
	@OneToMany(mappedBy = "module")
	private List<Enrollments> enrollments;
	
	@OneToMany(mappedBy = "module")
	private List<AttendanceListing> attendances;
	
	public List<AttendanceListing> getAttendances() {
		return attendances;
	}
	public void setAttendances(List<AttendanceListing> attendances) {
		this.attendances = attendances;
	}
	public List<Enrollments> getEnrollment() {
		return enrollments;
	}
	public void setEnrollment(List<Enrollments> enrollments) {
		this.enrollments = enrollments;
	}
	public String getShortCode() {
		return shortCode;
	}
	public void setShortCode(String shortCode) {
		this.shortCode = shortCode;
	}
	public String getLongName() {
		return longName;
	}
	public void setLongName(String longName) {
		this.longName = longName;
	}
}
