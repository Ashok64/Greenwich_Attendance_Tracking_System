package com.university.greenwich.dto;

import java.util.List;

import com.university.greenwich.entity.AttendanceListing;
import com.university.greenwich.entity.Enrollments;

public class StudentDTO {
	private int studentID;
	private String studentName;
	private String studentEmail;
	private List<Enrollments> enrollments;
	private List<AttendanceListing> attendances;
	
	public StudentDTO() {}
	
	public StudentDTO(int studentID, String studentName, String studentEmail) {
		super();
		this.studentID = studentID;
		this.studentName = studentName;
		this.studentEmail = studentEmail;
	}

	public int getStudentID() {
		return studentID;
	}

	public void setStudentID(int studentID) {
		this.studentID = studentID;
	}

	public String getStudentName() {
		return studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}

	public String getStudentEmail() {
		return studentEmail;
	}

	public void setStudentEmail(String studentEmail) {
		this.studentEmail = studentEmail;
	}

	public List<Enrollments> getEnrollments() {
		return enrollments;
	}
	public void setEnrollments(List<Enrollments> enrollments) {
		this.enrollments = enrollments;
	}
	public List<AttendanceListing> getAttendances() {
		return attendances;
	}
	public void setAttendances(List<AttendanceListing> attendances) {
		this.attendances = attendances;
	}
}
