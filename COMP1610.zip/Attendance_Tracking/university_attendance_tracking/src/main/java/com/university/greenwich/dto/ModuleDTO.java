package com.university.greenwich.dto;

import java.util.List;

import com.university.greenwich.entity.AttendanceListing;
import com.university.greenwich.entity.Enrollments;

public class ModuleDTO {
	private String shortCode;
	private String longName;
	private List<Enrollments> enrollments;
	private List<AttendanceListing> attendances;
	
	public ModuleDTO() {}

	public ModuleDTO(String shortCode, String longName) {
		super();
		this.shortCode = shortCode;
		this.longName = longName;
	}

	public String getShortCode() {
		return shortCode;
	}

	public void setShortCode(String shortCode) {
		this.shortCode = shortCode;
	}


	public String getLongName() {
		return longName;
	}

	public void setLongName(String longName) {
		this.longName = longName;
	}

	public List<Enrollments> getEnrollments() {
		return enrollments;
	}
	public void setEnrollments(List<Enrollments> enrollments) {
		this.enrollments = enrollments;
	}
	public List<AttendanceListing> getAttendances() {
		return attendances;
	}
	public void setAttendances(List<AttendanceListing> attendances) {
		this.attendances = attendances;
	}
}
