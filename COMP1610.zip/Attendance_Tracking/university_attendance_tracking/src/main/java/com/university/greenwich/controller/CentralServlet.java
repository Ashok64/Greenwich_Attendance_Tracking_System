package com.university.greenwich.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.university.greenwich.dao.AttendanceListingDAO;
import com.university.greenwich.dao.ModuleDAO;
import com.university.greenwich.dao.StudentDAO;
import com.university.greenwich.dto.AttendanceDTO;
import com.university.greenwich.dto.ModuleDTO;
import com.university.greenwich.dto.StudentDTO;

@SuppressWarnings("serial")
@WebServlet("/CentralServlet")
public class CentralServlet extends HttpServlet{
	
	@EJB
	private ModuleDAO moduleDAO;
	
	@EJB
	private StudentDAO studentDAO;
	
	@EJB
	private AttendanceListingDAO attendanceDAO;
	
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String action = request.getParameter("action");
		
		if(action == null) {
			action = "homePage";
		}
		
		if(action.equals("homePage")) {
			homePage(request,response);
		}
		else if(action.equals("listAttendance")) {
			String moduleCode = request.getParameter("moduleCode");
			int date = Integer.parseInt(request.getParameter("date"));
			request.setAttribute("date", date);
			
			ModuleDTO module = moduleDAO.getModuleByCode(moduleCode);
			request.setAttribute("module", module);
			
			List<StudentDTO> studentsList = studentDAO.getStudentsByModule(moduleCode);
			request.setAttribute("studentsList", studentsList);
			
			RequestDispatcher rd = request.getRequestDispatcher("pages/listAttendance.jsp");
			rd.forward(request, response);
		}
		else if(action.equals("attendanceListing")){
			List<ModuleDTO> modulesList = moduleDAO.getAllModules();
			request.setAttribute("modulesList", modulesList);
			
			RequestDispatcher rd = request.getRequestDispatcher("pages/attendanceListing.jsp");
			rd.forward(request, response);
		}
		else if(action.equals("attendanceReport")) {
			List<StudentDTO> studentsList = studentDAO.getAllStudents();
			request.setAttribute("studentsList", studentsList);
			
			RequestDispatcher rd = request.getRequestDispatcher("pages/attendanceReport.jsp");
			rd.forward(request, response);
		}
		else if(action.equals("displayAttendanceReport")) {
			String studID = request.getParameter("studentID");
			StudentDTO stud = studentDAO.getStudentByID(Integer.parseInt(studID));
			String studName = stud.getStudentName();
			request.setAttribute("studName", studName);
			
			List<AttendanceDTO> attendanceListById = attendanceDAO.getAttendanceByStudent(Integer.parseInt(studID));
			request.setAttribute("attendanceListById",attendanceListById);
			
			List<ModuleDTO> modulesList = moduleDAO.getModulesByID(Integer.parseInt(studID));
			request.setAttribute("modulesList", modulesList);
			request.setAttribute("studentID", studID);
			
			RequestDispatcher rd = request.getRequestDispatcher("pages/displayAttendanceReport.jsp");
			rd.forward(request,response);
		}
		else if(action.equals("addStudent")) {
			RequestDispatcher rd = request.getRequestDispatcher("pages/addStudent.jsp");
			rd.forward(request, response);
		}
		
	}
	
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		String action = request.getParameter("action");
		if("markAttendance".equals(action)) {
			String moduleCode = request.getParameter("moduleCode");
			int attendanceDate = Integer.parseInt(request.getParameter("date"));
			
			String studentIds[] = request.getParameterValues("studentIds"); 
			Map<Integer,String> attendanceMap = new HashMap<>();
			for(String studID:studentIds) {
				boolean present = request.getParameter("attendance_"+studID)!=null;
				if(present == true) {
				   attendanceMap.put(Integer.parseInt(studID), "present");
				}else {
					attendanceMap.put(Integer.parseInt(studID), "absent");
				}
			}
			
			attendanceDAO.markAttendance(moduleCode,attendanceMap,attendanceDate);
			homePage(request,response);
		}
		else if(action.equals("insertStudent")) {
			int id = Integer.parseInt(request.getParameter("id"));
			String name = request.getParameter("name");
			String email = request.getParameter("email");
			
			StudentDTO sDTO = new StudentDTO(id,name,email);
			
			studentDAO.addStudent(sDTO);
			homePage(request,response);
		}
		else if(action.equals("enrollStudent")) {
			enrollStudent(request,response);
		}
	}
	
	private void homePage(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		List<ModuleDTO> modulesList = moduleDAO.getAllModules();
		request.setAttribute("modulesList", modulesList);
		
		RequestDispatcher rd = request.getRequestDispatcher("pages/index.jsp");
		rd.forward(request, response);
	}
	
	private void enrollStudent(HttpServletRequest req, HttpServletResponse res) {
		
	}
}
