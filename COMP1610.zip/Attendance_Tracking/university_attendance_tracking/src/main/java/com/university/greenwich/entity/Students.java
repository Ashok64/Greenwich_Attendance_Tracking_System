package com.university.greenwich.entity;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Students {
	
	@Id
	private int studentID;
	
	private String studentName;
	
    private String studentEmail;
	
	@OneToMany(mappedBy = "student")
	private List<Enrollments> enrollments;
	
	@OneToMany(mappedBy = "student")
	private List<AttendanceListing> attendances;

	public List<AttendanceListing> getAttendances() {
		return attendances;
	}
	public void setAttendances(List<AttendanceListing> attendances) {
		this.attendances = attendances;
	}
	public List<Enrollments> getEnrollment() {
		return enrollments;
	}
	public void setEnrollment(List<Enrollments> enrollments) {
		this.enrollments = enrollments;
	}
	public int getStudentID() {
		return studentID;
	}
	public void setStudentID(int studentID) {
		this.studentID = studentID;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public String getStudentEmail() {
		return studentEmail;
	}
	public void setStudentEmail(String studentEmail) {
		this.studentEmail = studentEmail;
	}
}
