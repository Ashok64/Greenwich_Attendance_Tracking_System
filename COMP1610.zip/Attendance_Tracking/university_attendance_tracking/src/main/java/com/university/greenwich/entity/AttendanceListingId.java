package com.university.greenwich.entity;

import java.io.Serializable;
import java.util.Objects;

import javax.persistence.Embeddable;

@SuppressWarnings("serial")
@Embeddable
public class AttendanceListingId implements Serializable{
	
	private int student;
	private String module;
	private int date_of_attendance;
	
	public AttendanceListingId() {}
	
	public AttendanceListingId(int student, String module, int date_of_attendance) {
		super();
		this.student = student;
		this.module = module;
		this.date_of_attendance = date_of_attendance;
	}

	public int getStudentId() {
		return student;
	}

	public void setStudentId(int student) {
		this.student = student;
	}

	public String getModuleCode() {
		return module;
	}

	public void setModuleCode(String moduleCode) {
		this.module = moduleCode;
	}

	public int getDate_of_attendance() {
		return date_of_attendance;
	}

	public void setDate_of_attendance(int date_of_attendance) {
		this.date_of_attendance = date_of_attendance;
	}

	@Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        AttendanceListingId that = (AttendanceListingId) o;
        return Objects.equals(student,that.student) &&
        		Objects.equals(module,that.module) &&
        		date_of_attendance == that.date_of_attendance;
        		
    }

    @Override
    public int hashCode() {
        return Objects.hash(student, module, date_of_attendance);
    }
}
