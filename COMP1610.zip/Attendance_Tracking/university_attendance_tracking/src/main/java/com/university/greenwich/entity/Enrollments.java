package com.university.greenwich.entity;


import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
@IdClass(EnrollmentsId.class)
public class Enrollments {
	
	@Id
	@ManyToOne
	@JoinColumn(name="studentID")
	private Students student;
	
	@Id
	@ManyToOne
	@JoinColumn(name="moduleCode")
	private Modules module;
	
	public Students getStudent() {
		return student;
	}
	public void setStudent(Students student) {
		this.student = student;
	}
	public Modules getModule() {
		return module;
	}
	public void setModule(Modules module) {
		this.module = module;
	}
	
}
