package com.university.greenwich.client;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.university.greenwich.dto.AttendanceDTO;
import com.university.greenwich.dto.ModuleDTO;
import com.university.greenwich.dto.StudentDTO;

public class ClientApplication {
    private static final String BASE_URL = "http://localhost:8080/university_attendance_tracking/api/attendance";
    private static final ObjectMapper objectMapper = new ObjectMapper();

    public static void main(String[] args) {
        try (CloseableHttpClient httpClient = HttpClients.createDefault();
             BufferedReader reader = new BufferedReader(new InputStreamReader(System.in))) {

            while (true) {
                displayMenu();
                String choice = reader.readLine();
                handleUserChoice(choice, httpClient, reader);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void displayMenu() {
        System.out.println("Choose an option:");
        System.out.println("1. List All Modules");
        System.out.println("2. List All Students");
        System.out.println("3. Students Enrolled in a Module");
        System.out.println("4. Attendance for all the modules Enrolled by a Student");
        System.out.println("5. Exit");
    }

    private static void handleUserChoice(String choice, CloseableHttpClient httpClient, BufferedReader reader) throws IOException {
        try {
            switch (choice) {
                case "1":
                    listModules(httpClient);
                    break;
                case "2":
                    listStudents(httpClient);
                    break;
                case "3":
                    enrolledStudentsByModule(httpClient, reader);
                    break;
                case "4":
                    getAttendance(httpClient, reader);
                    break;
                case "5":
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        } catch (Exception e) {
            System.out.println("An error occurred: " + e.getMessage());
        }
    }

    private static void listStudents(CloseableHttpClient httpClient) throws Exception {
        HttpGet request = new HttpGet(BASE_URL + "/students");
        executeRequest(httpClient, request, StudentDTO[].class, 
            students -> {
                for (StudentDTO student : students) {
                    System.out.println("ID: " + student.getStudentID() + ", Name: " + student.getStudentName() + ", Email: " + student.getStudentEmail());
                }
            }
        );
    }

    private static void listModules(CloseableHttpClient httpClient) throws Exception {
        HttpGet request = new HttpGet(BASE_URL + "/modules");
        executeRequest(httpClient, request, ModuleDTO[].class, 
            modules -> {
                for (ModuleDTO module : modules) {
                    System.out.println("Code: " + module.getShortCode() + ", Name: " + module.getLongName());
                }
            }
        );
    }

    private static void enrolledStudentsByModule(CloseableHttpClient httpClient, BufferedReader reader) throws Exception {
        System.out.print("Enter Module code: ");
        String moduleCode = reader.readLine();
        HttpGet request = new HttpGet(BASE_URL + "/students/" + moduleCode);
        executeRequest(httpClient, request, StudentDTO[].class, 
            students -> {
                for (StudentDTO student : students) {
                    System.out.println("ID: " + student.getStudentID() + ", Name: " + student.getStudentName() + ", Email: " + student.getStudentEmail());
                }
            }
        );
    }

    private static void getAttendance(CloseableHttpClient httpClient, BufferedReader reader) throws Exception {
        System.out.print("Enter Student ID: ");
        int studentID = Integer.parseInt(reader.readLine());
        HttpGet request = new HttpGet(BASE_URL + "/attendanceList/" + studentID);
        executeRequest(httpClient, request, AttendanceDTO[].class, 
            attendance -> {
                for (AttendanceDTO a : attendance) {
                    System.out.println("ID: " + a.getStudentID() + ", Module Code: " + a.getModuleCode() + ", Date: " + a.getDate_of_attendance() + ", Attendance: " + a.getPresent_absent());
                }
            }
        );
    }

    private static <T> void executeRequest(CloseableHttpClient httpClient, HttpGet request, Class<T[]> responseType, ResultHandler<T> handler) throws IOException {
        try (CloseableHttpResponse response = httpClient.execute(request)) {
            HttpEntity entity = response.getEntity();
            if (entity != null) {
                String result = EntityUtils.toString(entity);
                T[] data = objectMapper.readValue(result, responseType);
                handler.handleResult(data);
            }
        } catch (Exception e) {
            System.out.println("An error occurred: " + e.getMessage());
        }
    }

    @FunctionalInterface
    private interface ResultHandler<T> {
        void handleResult(T[] data) throws IOException;
    }
}
