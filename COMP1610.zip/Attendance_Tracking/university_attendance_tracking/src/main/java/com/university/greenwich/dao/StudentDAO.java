package com.university.greenwich.dao;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import com.university.greenwich.dto.StudentDTO;
import com.university.greenwich.entity.Students;

@Stateless
public class StudentDAO{
	
	EntityManagerFactory emf = Persistence.createEntityManagerFactory("UniversityGreenwichPU");
	EntityManager em = emf.createEntityManager();
	
	public List<StudentDTO> getAllStudents() {
	    List<Students> students = fetchAllStudents();
	    return convertToDTOList(students);
	}

	private List<Students> fetchAllStudents() {
	    TypedQuery<Students> query = em.createQuery("SELECT s FROM Students s", Students.class);
	    return query.getResultList();
	}
	
	public StudentDTO getStudentByID(int studID) {
		Students student = em.find(Students.class, studID);
		return convertToDTO(student);
	}
	
	public void addStudent(StudentDTO sDTO) {
		Students s=new Students();
		s.setStudentID(sDTO.getStudentID());
		s.setStudentName(sDTO.getStudentName());
		s.setStudentEmail(sDTO.getStudentEmail());
		
		em.getTransaction().begin();
		em.merge(s);
		em.getTransaction().commit();
	}
	
	public List<StudentDTO> getStudentsByModule(String code) {
	    List<Students> students = fetchStudentsByModuleCode(code);
	    return convertToDTOList(students);
	}

	private List<Students> fetchStudentsByModuleCode(String code) {
	    String jpql = "SELECT s FROM Students s JOIN s.enrollments e WHERE e.module.shortCode = :code";
	    TypedQuery<Students> query = em.createQuery(jpql, Students.class);
	    query.setParameter("code", code);
	    return query.getResultList();
	}
	
	private List<StudentDTO> convertToDTOList(List<Students> students) {
	    List<StudentDTO> studentDTOs = new ArrayList<>();
	    for (Students student : students) {
	        StudentDTO studentDTO = convertToDTO(student);
	        studentDTOs.add(studentDTO);
	    }
	    return studentDTOs;
	}
	
	private StudentDTO convertToDTO(Students student) {
        StudentDTO dto = new StudentDTO();
        dto.setStudentID(student.getStudentID());
        dto.setStudentName(student.getStudentName());
        dto.setStudentEmail(student.getStudentEmail());
        dto.setEnrollments(student.getEnrollment());
        dto.setAttendances(student.getAttendances());
        return dto;
	}
}
