package com.university.greenwich.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
@IdClass(AttendanceListingId.class)
public class AttendanceListing {
	
	@Id
	@ManyToOne
	@JoinColumn(name="studentID")
	private Students student;
	
	@Id
	@ManyToOne
	@JoinColumn(name="moduleCode")
	private Modules module;
	
	@Id
	private int date_of_attendance;
	
	private String present_absent;
	
	public AttendanceListing() {}

	public AttendanceListing(Students student, Modules module, int date_of_attendance, String present_absent) {
		super();
		this.student = student;
		this.module = module;
		this.date_of_attendance = date_of_attendance;
		this.present_absent = present_absent;
	}

	public Students getStudent() {
		return student;
	}

	public void setStudent(Students student) {
		this.student = student;
	}

	public Modules getModule() {
		return module;
	}

	public void setModule(Modules module) {
		this.module = module;
	}

	public int getDate_of_attendance() {
		return date_of_attendance;
	}

	public void setDate_of_attendance(int date_of_attendance) {
		this.date_of_attendance = date_of_attendance;
	}

	public String getPresent_absent() {
		return present_absent;
	}

	public void setPresent_absent(String present_absent) {
		this.present_absent = present_absent;
	}
}
