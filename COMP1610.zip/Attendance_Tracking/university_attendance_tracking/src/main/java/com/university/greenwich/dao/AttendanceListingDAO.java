package com.university.greenwich.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import com.university.greenwich.dto.AttendanceDTO;
import com.university.greenwich.entity.AttendanceListing;
import com.university.greenwich.entity.Modules;
import com.university.greenwich.entity.Students;

@Stateless
public class AttendanceListingDAO{
	
	EntityManagerFactory emf = Persistence.createEntityManagerFactory("UniversityGreenwichPU");
	EntityManager em = emf.createEntityManager();
	
	public List<AttendanceDTO> getAttendanceByStudent(int studentID) {
	    Students student = em.find(Students.class, studentID);
	    List<AttendanceListing> attendance = fetchAttendanceByStudent(student);
	    return convertToDTOList(attendance);
	}
	
	private List<AttendanceListing> fetchAttendanceByStudent(Students student) {
	    TypedQuery<AttendanceListing> query = em.createQuery(
	        "SELECT a FROM AttendanceListing a WHERE a.student = :student",
	        AttendanceListing.class
	    );
	    query.setParameter("student", student);
	    return query.getResultList();
	}
	
	public void markAttendance(String moduleCode, Map<Integer, String> attendanceMap, int attendanceDate) {
		Modules module = em.find(Modules.class, moduleCode);
		
		for(Map.Entry<Integer,String> map: attendanceMap.entrySet()) {
			int studentID = map.getKey();
			String attendance  = map.getValue();
			Students student = em.find(Students.class, studentID);
			
			AttendanceListing a = new AttendanceListing();
			a.setStudent(student);
			a.setModule(module);
			a.setDate_of_attendance(attendanceDate);
			a.setPresent_absent(attendance);
			
			em.getTransaction().begin();
			em.merge(a);
			em.getTransaction().commit();
		}
	}
	
	private List<AttendanceDTO> convertToDTOList(List<AttendanceListing> attendance) {
	    List<AttendanceDTO> attendanceDTOs = new ArrayList<>();
	    for (AttendanceListing record : attendance) {
	        AttendanceDTO attendanceDTO = convertToDTO(record);
	        attendanceDTOs.add(attendanceDTO);
	    }
	    return attendanceDTOs;
	}
	
	private AttendanceDTO convertToDTO(AttendanceListing attendance) {
        AttendanceDTO dto = new AttendanceDTO();
        dto.setStudent(attendance.getStudent());
        dto.setModule(attendance.getModule());
        dto.setDate_of_attendance(attendance.getDate_of_attendance());
        dto.setPresent_absent(attendance.getPresent_absent());
        return dto;
    }
}
