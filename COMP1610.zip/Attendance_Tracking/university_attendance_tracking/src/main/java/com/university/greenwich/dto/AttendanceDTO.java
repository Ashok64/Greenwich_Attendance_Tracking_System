package com.university.greenwich.dto;

import com.university.greenwich.entity.Modules;
import com.university.greenwich.entity.Students;

public class AttendanceDTO {
	private int studentID;
	private String moduleCode;
	private Students student;
	private Modules module;
	private int date_of_attendance;
	private String present_absent;
	public AttendanceDTO() {}

	public AttendanceDTO(int studentID, String moduleCode, int date_of_attendance, String present_absent) {
		super();
		this.studentID = studentID;
		this.moduleCode = moduleCode;
		this.date_of_attendance = date_of_attendance;
		this.present_absent = present_absent;
	}
	
	public int getStudentID() {
		return studentID;
	}
	public void setStudentID(int studentID) {
		this.studentID = studentID;
	}
	public String getModuleCode() {
		return moduleCode;
	}
	public void setModuleCode(String moduleCode) {
		this.moduleCode = moduleCode;
	}
	public Students getStudent() {
		return student;
	}
	public void setStudent(Students student) {
		this.student = student;
	}
	public Modules getModule() {
		return module;
	}
	public void setModule(Modules module) {
		this.module = module;
	}

	public int getDate_of_attendance() {
		return date_of_attendance;
	}

	public void setDate_of_attendance(int date_of_attendance) {
		this.date_of_attendance = date_of_attendance;
	}

	public String getPresent_absent() {
		return present_absent;
	}

	public void setPresent_absent(String present_absent) {
		this.present_absent = present_absent;
	}
}
