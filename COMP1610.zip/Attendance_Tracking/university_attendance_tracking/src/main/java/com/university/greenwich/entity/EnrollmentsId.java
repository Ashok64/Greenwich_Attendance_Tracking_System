package com.university.greenwich.entity;

import java.io.Serializable;
import java.util.Objects;
import javax.persistence.Embeddable;

@SuppressWarnings("serial")
@Embeddable
public class EnrollmentsId implements Serializable{
	
	private int student;
	private String module;
	
	public EnrollmentsId() {}
	
	public EnrollmentsId(int student, String module) {
		this.student = student;
		this.module = module;
	}
	public int getStudent_id() {
		return student;
	}
	public void setStudent_id(int student) {
		this.student= student;
	}
	public String getModule_code() {
		return module;
	}
	public void setModule_code(String module) {
		this.module = module;
	}
	
	// hashCode and equals methods
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        EnrollmentsId that = (EnrollmentsId) o;
        return Objects.equals(student, that.student) && Objects.equals(module, that.module);
    }

    @Override
    public int hashCode() {
        return Objects.hash(student, module);
    }
}
