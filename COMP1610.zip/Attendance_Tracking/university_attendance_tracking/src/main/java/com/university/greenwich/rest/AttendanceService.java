package com.university.greenwich.rest;

import java.util.List;
import java.util.stream.Collectors;

import javax.inject.Inject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.university.greenwich.dao.AttendanceListingDAO;
import com.university.greenwich.dao.ModuleDAO;
import com.university.greenwich.dao.StudentDAO;
import com.university.greenwich.dto.AttendanceDTO;
import com.university.greenwich.dto.ModuleDTO;
import com.university.greenwich.dto.StudentDTO;

@Path("/attendance")
public class AttendanceService {
	@Inject
	private StudentDAO sDAO;
	
	@Inject
	private ModuleDAO mDAO;
	
	@Inject
	private AttendanceListingDAO aDAO;
	
	@GET
	@Path("/students")
	@Produces(MediaType.APPLICATION_JSON)
	public List<StudentDTO> fetchAllStudents(){
		List<StudentDTO> students = sDAO.getAllStudents();
		return students.stream()
	            .map(student -> new StudentDTO(student.getStudentID(), student.getStudentName(),student.getStudentEmail()))
	            .collect(Collectors.toList());
		
	}
	
	@GET
	@Path("/students/{code}")
	@Produces(MediaType.APPLICATION_JSON)
	public List<StudentDTO> fetchStudentsByModule(@PathParam("code") String code){
		List<StudentDTO> students = sDAO.getStudentsByModule(code);
		return students.stream()
	            .map(student -> new StudentDTO(student.getStudentID(), student.getStudentName(),student.getStudentEmail()))
	            .collect(Collectors.toList());
	}
	
	
	@GET
	@Path("/modules")
	@Produces(MediaType.APPLICATION_JSON)
	public List<ModuleDTO> fetchModules(){
		List<ModuleDTO> modules = mDAO.getAllModules();
		return modules.stream()
	            .map(module -> new ModuleDTO(module.getShortCode(), module.getLongName()))
	            .collect(Collectors.toList());
	}
	
	@GET
	@Path("/attendanceList/{id}")
	@Produces(MediaType.APPLICATION_JSON)
	public List<AttendanceDTO> fetchAttendanceByStudent(@PathParam("id") int id){
		List<AttendanceDTO> attendances = aDAO.getAttendanceByStudent(id);
		return attendances.stream()
	            .map(attendance -> new AttendanceDTO(attendance.getStudent().getStudentID(), attendance.getModule().getShortCode(), attendance.getDate_of_attendance(), attendance.getPresent_absent()))
	            .collect(Collectors.toList());
	}
}
