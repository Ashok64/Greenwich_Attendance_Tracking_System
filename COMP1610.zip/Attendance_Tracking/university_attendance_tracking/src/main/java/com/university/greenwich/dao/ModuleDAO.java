package com.university.greenwich.dao;

import java.util.ArrayList;
import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import com.university.greenwich.dto.ModuleDTO;
import com.university.greenwich.entity.Modules;

@Stateless
public class ModuleDAO{
	
	EntityManagerFactory emf = Persistence.createEntityManagerFactory("UniversityGreenwichPU");
	EntityManager em = emf.createEntityManager();
	
	public ModuleDTO getModuleByCode(String code) {
		Modules module = em.find(Modules.class, code);
		return convertToDTO(module);
	}
	
	public List<ModuleDTO> getAllModules() {
	    List<Modules> modules = em.createQuery("SELECT m FROM Modules m", Modules.class)
	                              .getResultList();
	    return convertToDTOList(modules);
	}
	
	public List<ModuleDTO> getModulesByID(int studentID) {
	    List<Modules> modules = fetchModulesByStudentID(studentID);
	    return convertToDTOList(modules);
	}

	private List<Modules> fetchModulesByStudentID(int studentID) {
	    String jpql = "SELECT m FROM Modules m JOIN m.enrollments e WHERE e.student.studentID = :studentID";
	    TypedQuery<Modules> query = em.createQuery(jpql, Modules.class);
	    query.setParameter("studentID", studentID);
	    return query.getResultList();
	}
	
	
	private List<ModuleDTO> convertToDTOList(List<Modules> modules) {
	    List<ModuleDTO> moduleDTOs = new ArrayList<>();
	    for (Modules module : modules) {
	        ModuleDTO moduleDTO = convertToDTO(module);
	        moduleDTOs.add(moduleDTO);
	    }
	    return moduleDTOs;
	}
	
	private ModuleDTO convertToDTO(Modules module) {
        ModuleDTO dto = new ModuleDTO();
        dto.setShortCode(module.getShortCode());
        dto.setLongName(module.getLongName());
        dto.setEnrollments(module.getEnrollment());
        dto.setAttendances(module.getAttendances());
        return dto;
	}
}
